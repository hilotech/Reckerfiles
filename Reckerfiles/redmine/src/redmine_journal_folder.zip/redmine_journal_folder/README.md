# Redmine journal folder plugin

This plug-in allows to fold comments of tickets.<br>

## Installation
1. Put this plugin in plugin directory.
1. Restart Redmine.

## Screenshot
![](resource/Screenshot.gif)