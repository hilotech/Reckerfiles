require 'redmine_zenedit'

Redmine::Plugin.register :redmine_zenedit do
  name 'Redmine Zen Edit plugin'
  author 'RedmineCRM'
  description 'This is a Zen edit plugin for Redmine'
  version '0.0.2'
  url 'http://redminecrm.com'
  author_url 'mailto:support@redminecrm.com'
end
