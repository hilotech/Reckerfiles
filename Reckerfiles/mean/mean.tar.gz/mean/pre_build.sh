#!/bin/bash

# Write here pre-build process
