#!/bin/bash

# Write here post-build process
