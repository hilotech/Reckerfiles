RUN_AS_SERVICE=1
EXEC=
AUTOMAP_PORT_HTTP=1
AUTOMAP_PORT_SSH=1
VOLUMES=
PORTS=
LINKS=
BASE_IMAGE=
SET _USERNAME="localadm"
SET _SSH_PUBLIC_KEY="ssh-rsa__AAAAB3NzaC1yc..."
# SET is not able to handle white-spaces in string.
# Use DOUBLE-UNDER-BAR (__) instead.
